package com.company.JavaAdvanced2021Sep.DefiningClassesLab.RawData;

public class Type {
    private double pressure1;
    private int age1;
    private double pressure2;
    private int age2;
    private double pressure3;
    private int age3;
    private double pressure4;
    private int age4;

    public Type(double pressure1, int age1, double pressure2, int age2, double pressure3, int age3, double pressure4, int age4) {
        this.pressure1 = pressure1;
        this.age1 = age1;
        this.pressure2 = pressure2;
        this.age2 = age2;
        this.pressure3 = pressure3;
        this.age3 = age3;
        this.pressure4 = pressure4;
        this.age4 = age4;
    }

    public double getPressure1() {
        return pressure1;
    }

    public void setPressure1(double pressure1) {
        this.pressure1 = pressure1;
    }

    public int getAge1() {
        return age1;
    }

    public void setAge1(int age1) {
        this.age1 = age1;
    }

    public double getPressure2() {
        return pressure2;
    }

    public void setPressure2(double pressure2) {
        this.pressure2 = pressure2;
    }

    public int getAge2() {
        return age2;
    }

    public void setAge2(int age2) {
        this.age2 = age2;
    }

    public double getPressure3() {
        return pressure3;
    }

    public void setPressure3(double pressure3) {
        this.pressure3 = pressure3;
    }

    public int getAge3() {
        return age3;
    }

    public void setAge3(int age3) {
        this.age3 = age3;
    }

    public double getPressure4() {
        return pressure4;
    }

    public void setPressure4(double pressure4) {
        this.pressure4 = pressure4;
    }

    public int getAge4() {
        return age4;
    }

    public void setAge4(int age4) {
        this.age4 = age4;
    }
}
